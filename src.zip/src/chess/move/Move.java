/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chess.move;

import chess.board.PieceType;
import chess.coordinate.Coordinate;
import static chess.move.MoveType.CASTLE;

/**
 *
 * @author Phoenix
 */
public class Move {
    
    private final PieceType pieceType;
    private final Coordinate coordFrom;
    private final Coordinate coordTo;
    private final MoveType moveType;
    private final Coordinate optPieceCoord;
    private final PieceType promoteTo;
    
    public Move(PieceType pieceType, Coordinate coordFrom, Coordinate coordTo, 
                                                           MoveType moveType) {
        this.pieceType = pieceType;
        this.coordFrom = coordFrom;
        this.coordTo = coordTo;
        this.moveType = moveType;
        this.optPieceCoord = null;
        this.promoteTo = null;
    }

    public Move(PieceType pieceType, Coordinate coordFrom, Coordinate coordTo, 
            MoveType moveType, Coordinate optionalCoord, PieceType promoteTo) {
        this.pieceType = pieceType;
        this.coordFrom = coordFrom;
        this.coordTo = coordTo;
        this.moveType = moveType; 
        this.optPieceCoord = optionalCoord;
        this.promoteTo=promoteTo;
    }
    
    public PieceType getPieceType() {
        return pieceType;
    }

    public Coordinate getCoordFrom() {
        return coordFrom;
    }

    public Coordinate getCoordTo() {
        return coordTo;
    }

    public MoveType getMoveType() {
        return moveType;
    }
    
    public Coordinate getOptionalPieceCoord(){
        return optPieceCoord;
    }   

    public Coordinate getOptPieceCoord() {
        return optPieceCoord;
    }

    public PieceType getPromoteTo() {
        return promoteTo;
    }

    @Override
    public String toString() {
        if(moveType == CASTLE){
           if(coordTo.getY()==1) return "0-0";
           else return "0-0-0";
        }   
        if(promoteTo!=null) return ""+coordFrom+moveType.toString()+coordTo+promoteTo;
        return ""+pieceType+coordFrom+moveType.toString()+coordTo;      
    }

    
}
